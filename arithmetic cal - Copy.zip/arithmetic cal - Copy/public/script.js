let history = "";
let currentInput = "";


document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("login-form");
    const loginUsername = document.getElementById("login-username");
    const loginPassword = document.getElementById("login-password");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const username = loginUsername.value;
        const password = loginPassword.value;

        // Create an object with the login data
        const loginData = {
            username: username,
            password: password
        };

        // Send a POST request to your backend for user login
        fetch("/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(loginData)
        })
        .then((response) => {
            if (response.status === 200) {
                console.log("Login successful.");
                // Redirect to the calculator page or perform other actions on success
                window.location.href = "/index.html"; // Replace with your calculator page URL
            } else {
                console.error("Login failed.");
                // Handle login failure, e.g., show an error message
            }
        })
        .catch((error) => {
            console.error("Error:", error);
        });
    });
});
fetch("/register", {
    method: "POST",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify(registrationData)
})
.then((response) => {
    if (response.status === 200) {
        console.log("Registration successful.");
        // Redirect to the login page or perform other actions on success
        window.location.href = "/login.html"; // Replace with your login page URL
    } else {
        console.error("Registration failed.");
        // Handle registration failure, e.g., show an error message
    }
})
.catch((error) => {
    console.error("Error:", error);
});

function appendToDisplay(value) {
    currentInput += value;
    document.getElementById("display").value = currentInput;
}

function calculateMod() {
    currentInput += "%";
    document.getElementById("display").value = currentInput;
}

function calculateSqrt() {
    try {
        currentInput = Math.sqrt(eval(currentInput));
        document.getElementById("display").value = currentInput;
    } catch (error) {
        document.getElementById("display").value = "Error";
    }
}

function clearDisplay() {
    currentInput = "";
    document.getElementById("display").value = "0";
}

function calculateResult() {
    try {
        let result = eval(currentInput);
        history += `${currentInput} = ${result}\n`;
        currentInput = result;
        document.getElementById("display").value = result;
        document.getElementById("history").value = history;

        // Send the entire calculation process to the server
        saveCalculation(history, result);
    } catch (error) {
        document.getElementById("display").value = "Error";
    }
}

function saveCalculation(calculation, result) {
    fetch("/save-calculation", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            calculation: calculation,
            result: result,
        }),
    })
    .then((response) => {
        if (response.status === 200) {
            console.log("Calculation saved successfully.");
        } else {
            console.error("Failed to save calculation.");
        }
    })
    .catch((error) => {
        console.error("Error:", error);
    });
}
function showHistory() {
    fetch("/get-history")
        .then((response) => response.json())
        .then((data) => {
            // Assuming you have a div with id "history-display" for displaying history
            const historyDisplay = document.getElementById("history-display");
            historyDisplay.innerHTML = ""; // Clear previous history

            // Loop through the calculations and append them to the history display
            data.forEach((calculation) => {
                const calculationDiv = document.createElement("div");
                calculationDiv.textContent = calculation.calculation;
                historyDisplay.appendChild(calculationDiv);
            });
        })
        .catch((error) => {
            console.error("Error:", error);
        });
}



