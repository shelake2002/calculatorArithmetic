const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const session = require("express-session");

const app = express();
const port = 3000;

mongoose.connect("mongodb://127.0.0.1:27017/calculator123", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const User = require("./model/User"); // Import the User model (adjust the path as needed)

// Define your User schema and model here
const calculationSchema = new mongoose.Schema({
    calculation: String,
    result: String,
});
const Calculation = mongoose.model("Calculation", calculationSchema);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static("public"));

app.post("/save-calculation", async (req, res) => {
    const { calculation, result } = req.body;

    try {
        const newCalculation = new Calculation({
            calculation, // Store the complete calculation
            result,
        });

        await newCalculation.save(); // Use await to wait for the save operation

        console.log("Calculation saved successfully.");
        res.sendStatus(200);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
});
app.get("/get-history", async (req, res) => {
    try {
        const calculations = await Calculation.find({}); // Fetch all calculations from the database
        res.json(calculations);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

app.use(express.static("public")); // Serve static files from a "public" folder

app.get("/", (req, res) => {
    // Here, you can serve your HTML page that contains both the calculator and login forms
    res.sendFile(__dirname + "/public/index.html"); // Adjust the path to your HTML file
});
app.post("/register", async (req, res) => {
    // Extract registration data from req.body
    const { username, password } = req.body;

    try {
        // Check if the username is already taken (you may want to add additional checks)
        const existingUser = await User.findOne({ username });

        if (existingUser) {
            // Username is already taken
            return res.status(400).json({ message: "Username is already in use." });
        }

        // Create a new user document in the database
        const newUser = new User({ username, password });

        // Save the new user
        await newUser.save();

        // Registration successful
        res.status(200).json({ message: "Registration successful." });
    } catch (error) {
        console.error("Registration error:", error);
        res.status(500).json({ message: "Registration failed." });
    }
});
// User Login
app.post("/login", passport.authenticate("local", {
    successRedirect: "/index.html?login=success", // Include a query parameter to indicate successful login
    failureRedirect: "/?login=failed", // Include a query parameter to indicate failed login
}));

// ...

// Define your calculator functionality here, including routes for saving calculations and retrieving history

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
